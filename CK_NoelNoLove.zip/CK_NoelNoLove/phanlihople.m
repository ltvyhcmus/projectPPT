function [a, b] = phanlihople(app, interval)
    % Phân tách chuỗi khoảng "a,b" thành hai giá trị số
    parts = split(interval, ',');
    if numel(parts) ~= 2
        error('Khoảng phân ly nghiệm không hợp lệ. Vui lòng nhập theo dạng "a,b".');
    end
    a = str2double(parts{1});
    b = str2double(parts{2});
    if isnan(a) || isnan(b) || a >= b
        error('Khoảng phân ly nghiệm không hợp lệ. Giá trị a phải nhỏ hơn b.');
    end
end