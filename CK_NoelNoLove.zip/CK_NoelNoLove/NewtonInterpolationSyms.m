        % Polynomial for Newton interpolation
        function polynomial = NewtonInterpolationSyms(app, xa, ya)
            syms x;
            n = length(xa);
            d = ya; % Divided differences table
            for i = 1:n
                for j = 1:i-1
                    d(i)=(d(j) - d(i))/(xa(j) - xa(i)); 
                end
            end
            polynomial = d(n);
            for i = n-1:-1:1
                polynomial = expand(polynomial * (x - xa(i)) + d(i));
            end
        end