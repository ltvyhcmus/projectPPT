function result = daohamtien_Oh2(x_data, y_data, h, x_value)
    index = find(x_data == x_value); 
    result = ( - y_data(index + 2) + 4 * y_data(index + 1) -3* y_data(index)) / (2*h);
end