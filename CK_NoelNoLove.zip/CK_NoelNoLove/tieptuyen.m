function [x, solanlap] = tieptuyen(app, fx, a, b, saiso)
    % Chuyển chuỗi fx thành symbolic để tính đạo hàm
    f_sym = str2sym(fx); % Biểu thức symbolic của f(x)
    df_sym = diff(f_sym); % Đạo hàm của f(x)
    
    % Chuyển f(x) và f'(x) thành các hàm số có thể gọi được
    fxi = matlabFunction(f_sym); 
    dfxi = matlabFunction(df_sym);

    x0 = (a + b) / 2; % Điểm khởi đầu
    solanlap = 0; % Đếm số lần lặp
    
    while true
        % Tính tiếp tuyến Newton
        x1 = x0 - fxi(x0) / dfxi(x0); 
        solanlap = solanlap + 1; % Tăng số lần lặp
        
        % Kiểm tra điều kiện hội tụ
        if abs(x1 - x0) < saiso
            break;
        end
        
        x0 = x1; % Cập nhật giá trị x0
    end
    
    x = x1; % Trả về nghiệm
end