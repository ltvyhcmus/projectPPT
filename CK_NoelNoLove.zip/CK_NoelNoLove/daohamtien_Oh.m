function result = daohamtien_Oh(x_data, y_data, h,  x_value)
    index = find(x_data == x_value);
        result = (y_data(index + 1) - y_data(index)) / (h);
end
