        % Polynomial for Lagrange interpolation
        function polynomial = LagrangeSyms(app, xa, ya)
            syms x;
            n = length(xa);
            polynomial = 0;
            for i = 1:n
                L = 1;
                for j = 1:n
                    if i ~= j
                        L = L * (x - xa(j)) / (xa(i) - xa(j));
                    end
                end
                polynomial = expand(polynomial + ya(i) * L);
            end
        end