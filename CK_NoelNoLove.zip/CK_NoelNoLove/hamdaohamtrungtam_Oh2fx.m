function result = hamdaohamtrungtam_Oh2fx(f, h, x_interpolate)
    result = (-f(x_interpolate + 2*h) + 8*f(x_interpolate + h) - 8*f(x_interpolate - h) + f(x_interpolate -2*h)) / (12*h);
end
%result = (f(x_interpolate + h) - 2 * f(x_interpolate) + f(x_interpolate - h)) / h^2;