        function [a1, a0, r2] = HoiQuyTuyenTinh(app, x, y)
            % Hoi quy tuyen tinh
            n = length(x);
            sumx = sum(x);
            sumy = sum(y);
            sumxy = sum(x.*y);
            sumx2 = sum(x.^2);
            xm = mean(x);
            ym = mean(y);

            a1 = (n*sumxy - sumx*sumy) / (n*sumx2 - sumx^2);
            a0 = ym - a1*xm;

            st = sum((y - ym).^2);
            sr = sum((y - (a1*x + a0)).^2);

            r2 = (st - sr) / st;            
        end