function [x, solanlap] = chiadoi(app, fx, a, b, saisochophep)
    fxi = str2func(['@(x)', fx]); % Chuyển chuỗi thành hàm số
    solanlap = 0; % Đếm số lần lặp
    while true
        c = (a + b) / 2; % Tính điểm giữa
        if fxi(a) * fxi(c) < 0
            b = c; % Nghiệm nằm trong khoảng [a, c]
        else
            a = c; % Nghiệm nằm trong khoảng [c, b]
        end
        solanlap = solanlap + 1; % Tăng số lần lặp
        if abs(a - b) < saisochophep
            break;
        end
    end
    x = c; % Trả về nghiệm
end