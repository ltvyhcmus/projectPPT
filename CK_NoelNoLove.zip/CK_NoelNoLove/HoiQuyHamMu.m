function [a, b, r2] = HoiQuyHamMu(app, x, y)
    % Hồi quy dạng y = a * x^b

    % Kiểm tra x và y có giá trị dương
    if any(x <= 0) || any(y <= 0)
        error('Giá trị của x và y phải dương để tính hồi quy theo dạng này.');
    end

    % Chuyển đổi log10
    X = log10(x); % log10(x)
    Y = log10(y); % log10(y)

    % Hồi quy tuyến tính Y = A0 + A1 * X
    [A1, A0, r2] = app.HoiQuyTuyenTinh(X, Y);

    % Chuyển đổi về a và b
    a = 10^A0; % a = 10^(A0)
    b = A1;    % b = A1
end