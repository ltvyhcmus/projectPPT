function result = daohamlui_Oh2( x_data, y_data, h, x_value)
    index = find(x_data == x_value); 
    result = (3*y_data(index) - 4*y_data(index - 1) + y_data(index - 2)) / (2 * h);
end
