function result = hamdaohamlui_Oh2fx(f, h, x_interpolate)
    result = (3*f(x_interpolate) - 4*f(x_interpolate - h) + f(x_interpolate - 2*h)) / (2 * h);
end
% result = (-f(x_interpolate + 2*h) + 4*f(x_interpolate + h) - 3*f(x_interpolate)) / (2 * h);